package com.mycompany.java;

public class debugjava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		boolean status = getStatus();
		System.out.println("Java program status is "+status);
	}

	static boolean getStatus(){
		return true;
	}
}
